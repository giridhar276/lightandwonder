## method1
# reading the file line by line for processing
with open("lang.txt","r") as fobj:
    for line in fobj:
        # remove whitespaces at the end
        print(line.strip())
        
# method2 - read the file using fobj.readlines()
with open("lang.txt","r") as fobj:
    print(fobj.readlines())
    
# method3 - read the file using fobj.read() - just like ctrl+A
# meant for reading files with ssmall size
with open("lang.txt","r") as fobj:
    print(fobj.read()) # string as output
    
# method4 - using csv library
import csv
with open("lang.txt","r") as fobj:
    reader = csv.reader(fobj) ## converting file object to csv object
    for line in reader:
        print(line)
    
    
