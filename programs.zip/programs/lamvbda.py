


def add(a,b):
    c = a + b
    return c

total = add(10,20)
print(total)

# lamba function
#inline function
# lambda is the replacment of the single line function
#syntax :  functionname = lambda variables : expression
#example:       add     = lambda a,b,c : sum(a+b+c)
add = lambda x,y: x + y
total = add(10,20)
print(total)



add = lambda x,y: x + " " + y
total = add("python","programming")
print(total)


lang = ["google","java","oracle"]
#output : ["www.google.com","www.java.com","www.oracle.com"]
output = []
for item in lang:
    output.append("www." + item + ".com")
print(output)


#method2 using lambda
def get_append(x):
    return "www." + x + ".com"
# map(function,iterable)
lang = ["google","java","oracle"]
output = list(map(get_append,lang))
print(output)

# method3 : calling lambda with  map()
output = list(map(lambda x:"www." + x + ".com",lang))
print(output)


data = [10,20,30]
print(list(map(lambda x: x+10,data)))

info = [1,2,3,4,5,6,7,8]
print(list(filter(lambda x: x%2==0,info)))
print(list(filter(lambda x: x%2,info)))


lang = ["google","java","oracle","unix","perl"]
print(list(filter(lambda x: len(x)==4,lang)))






















