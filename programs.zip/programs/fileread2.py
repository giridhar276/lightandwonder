import csv
try:
    citydict = dict()
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        header = fobj.readline()
        reader = csv.reader(fobj)
        for line in reader:
            citydict[line[2]] = 1
        print(citydict)
except FileNotFoundError as err:
    print("File not found.. please check")
    print(err)
except TypeError as err:
    print("Invalid operation.. please check")
    print(err)
except ValueError as err:
    print("Invalid validation")
    print(err)
except Exception as err:
    print("Some unknown error found")
    print(err)