
atup = (10,20,30)
print(atup)

print(atup.)

emplist = [["rita","singh",'1-1-95','F'],["rita","singh",'1-1-95','F']]


emplist = [("rita","singh",'1-1-95','F'),("rita","singh",'1-1-95','F')]