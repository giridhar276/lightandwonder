
aset = {10,20,20,30,30,30}
bset = {30,30,30,40,40,50}
print(aset)
print(bset)

print(aset.union(bset))
print(aset.intersection(bset))

print(aset.issubset(bset))
print(aset.issuperset(bset))

aset.add(10) # no change
print(aset)
aset.add(90)
print(aset)

alist = [10,10,10,10,20,30]
print(set(alist))
