
name = "python programming"
if "ram" in name:
    print("exists")
    
alist = [10,20,30]
if 30 in alist:
    print("exists")
    
    
book = {"chap1":10 ,"chap2":20}
if "chap2" in book:
    print("key exists")

if 20 in book.values():
    print("value exists")
    

aset = {10,10,10,20,30}
if 50 in aset:
    print("exists")
else:
    print("doesnt exist")
    
    
name = "python"
print(name * 10)

alist = [10,20,30]
print(alist * 3)



name = input("Enter any name :")
print(name)
print(type(name))

# typecasting - converting from one type to another
value = int(input("Enter any value:"))
print(type(value))







