
import json
try:
    with open("employees.json","r") as fobj:
        #converting file object to json object
        data = json.load(fobj)
        for item in data['Employees']:
            print(item['empId'])
            print(item['jobTitle'])
            print(item['firstName'])
            print("-----------------")
except Exception as err: # base class Exception or default exception
    print(err)