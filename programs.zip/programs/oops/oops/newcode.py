

# this program will be executed
import bikecode
