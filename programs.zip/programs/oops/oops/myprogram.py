

import program1

program1.method1()