



class Employee:
    def displayEmployee(self):
        print("Employee name :","ram")
    def getEmployee(self):
        print("hello")
        
# this condition will be always True if code is executed directly
if __name__ == "__main__":
    emp1 = Employee()
    emp1.displayEmployee()
    emp1.getEmployee()
    
    emp2 = Employee()
    emp2.displayEmployee()
    emp2.getEmployee()





