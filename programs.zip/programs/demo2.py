#method1 : all the methods will be imported to your program
import os
print(os.listddir())

# method2
import matplotlib.pyplot as plt
plt.plot([10,20],[15,30])

# method3 - only listdir is imported not everything
# importing required methods only
from os import listdir,name
print(listdir())
print(name)

# method4: # imporinting everything using *
from math import *
print(tan(1))
print(log(2))