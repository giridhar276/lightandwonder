import pdb

import requests
from bs4 import BeautifulSoup
pdb.set_trace()
pdb.b
class Scrapping :
    def __init__(self,url):
        self.url = url
    def readURL(self):
        try:
            self.response = requests.get(self.url)
            self.soup = BeautifulSoup(self.response.text, 'html.parser')
        except Exception as err:
            print(err)
    def captureData(self):
        try:
            for self.link in self.soup.find_all('a'):
                print(self.link.get('href'))
        except Exception as err:
            print(err)
url = "https://www.google.com"      
web = Scrapping(url)
web.readURL()
web.captureData()

