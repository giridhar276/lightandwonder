

import json
try:
    with open("employees.json","r") as fobj:
        #converting file object to json object
        data = json.load(fobj)
        for item in data['Employees']:
            #capturing all the values
            line= item.values()
            # converting to string
            final_line = ",".join(line)
            print(final_line)
except Exception as err: # base class Exception or default exception
    print(err)