
# keyword arguments
def display(b,a,c):
    print(a,b,c)

display(c=30,a=10,b=20)

# *object is the tuple
def values(*data):
    print(type(data))
    for val in data:
        print(val)

values(10,20,30,40,4,65,5,54,654,3,6554,3,"unix")


# **object is the dictionary
def value_info(*data,**info):
    print(data)
    for key,value in info.items():
        print(key,value)

value_info(10,20,30,first = 10,second = 20,third=20,fourth=40)








