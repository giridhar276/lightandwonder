## tradional way of opening the file
# write operation
fobj = open("language1.txt","w")
#if file has to be created in diffent path
#fobj = open("D:\\languages.txt","w")
fobj.write("python programming\n")
fobj.write("linux programming\n")
fobj.close()


fobj = open("languages.txt","a")
fobj.write("java programming\n")
fobj.write("scala programming\n")
fobj.close()

# pythonic way
# NOT required to close the file
# file will be closed automatically
with open("language1.txt","w") as fw:
    fw.write("hadoop admin\n")
    
# context manager    
with open("numbers.txt","w") as fnum:
    for val in range(1,100):
        # objects should be same type while concatenating
        fnum.write(str(val) + "\n")
        
        
        
        
        
    
    
    