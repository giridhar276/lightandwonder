

import csv
citynames = set()
with open("supermarket_sales.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for line in reader:
        citynames.add(line[2])
    
    for city in citynames:
        print(city)


