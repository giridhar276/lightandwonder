


import requests
from bs4 import BeautifulSoup

try:
    url = "https://www.google.com"
    response = requests.get(url)
    #print(response.status_code)
    #print(response.text)
    soup = BeautifulSoup(response.text, 'html.parser')

    for link in soup.find_all('a'):
        print(link.get('href'))
except Exception as err:
    print(err)