book = {"chap1":10 ,"chap2":20,"chap3":30}
print(book)
# adding new key:value
book["chap4"] = 40
book["chap5"] = 50
print(book)
# display keys
print(book.keys())
# display values
print(book.values())
# display items - list of tuples
print(book.items())
# remove key:value
book.pop("chap1") #chap1:10 will be removed
print(book)
book.popitem() # last key:value will be removed
print(book)
# iterating keys
for key in book.keys():
    print(key)
# iterating value
for value in book.values():
    print(value)
# display key,value
for key,value in book.items():
    print("Key :",key)
    print("Value:",value)
    

for key,value in book.items():
    print(type(key))


