
# class definition
class Employee:
    def __init__(self,name,age,gender,location):
        self.name = name
        self.age = age
        self.gender= gender
        self.location = location
    def displayEmp(self):
        print("name :",self.name)
        print("age  :", self.age)
        print("gender:",self.gender)
        print("location:",self.location)
# object creation        
emp1 = Employee("Ram",30,"M","Hyd")
# calling method
emp1.displayEmp()
    
# object creation        
emp2 = Employee("Rita",32,"F","Mumbai")
# calling method
emp2.displayEmp()


    