

# class definition
class Employee:
    def displayEmp(self,name):
        self.name = name
        print("Empname :",self.name)

# object creation        
emp1 = Employee()
# calling method
emp1.displayEmp("Ram")
    
# object creation        
emp2 = Employee()
# calling method
emp2.displayEmp("Rita")
    





# class definition
class Employee:
    def displayEmp(self,name):
        self.name = name
        print("Empname :",self.name)

# object creation        
emp1 = Employee()
# calling method
emp1.displayEmp("Ram")
    
# object creation        
emp2 = Employee()
# calling method
emp2.displayEmp("Rita")
    




