
name = "python programming"
print(name)
# displaying the string
print("I love", name)
#concatenation
print("I love" + "python programming")

#slicing
#string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:5])
print(name[-1])
print(name[-4:-2])



name = "python programming"

print(name.capitalize()) # first char in upper
print(name.upper())      # converting string to upper
print(name.lower())      # converting string to lower
print(name.isupper())    # validating whether string is upper or not
print(name.islower())    # validating whether string is lower or not
print(name.isalnum())    # alpha numeric or not
print(name.replace("python","ruby")) # replacing text
print(name)
#making changes permanent
output = name.replace("python","ruby")
print(output)

print(name.split(" "))
print(name.count("p"))
print(name.count("ram"))


print(name)
# condition
# simple if condition
name = "python"
if name.isupper():
    print("String is upper")
    print("inside if")
    print("still inside if")
    
    
########################################
# if -else#############################
if name.isupper():
    print("String is upper")
else:
    print("String is lower")
#########################################        
# if-elif-elif-elif..else################
if name.isupper():
    print("string is upper")
elif name.islower():
    print("string is lower")    
elif name.isalnum():
    print("String is alphanumeric")
else:
    print("Its something else")
    
    
# for loop
name = "python"
print(name)

print()
for char in name:
    if char in ["y","t","n"]:
        print(char)
"""
alist = [10,20,30]
for value in alist:
    print(value)
"""  
    


    
    
    
    
    
    
    
    

































