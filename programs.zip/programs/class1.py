
# class definition
class Employee:
    def displayEmp(self):
        print("Empname :","ram")
    
# object creation        
emp1 = Employee()
# calling method
emp1.displayEmp()
    

