
alist = [10,20,30,40,56,43,4,67,12]
print(alist.index(30))
#slicing
print(alist[0])
print(alist[-6:-3])
print(alist[0:5])
# adding single element to the end of the list
alist.append(9)
print("after appending :",alist)
# adding multiple elements to the end
alist.extend([93,49,19])
print("after extending:",alist)
# remove the first occurence of the value directly
alist.remove(10)
# remove with the index value
alist.pop(2)  # value at index 2 will be removed
#sorting in ascending ordre
alist.sort()  #alist.sort(reverse=True) # for descending
print("After sorting:",alist)
# reversing the values
alist.reverse()
print("After reversing:",alist)
#insert at desired location # list.insert(index,value)
alist.insert(40,4000)
print(alist)

# conditions
if len(alist) > 0 :
    print("list is not empty")
else:
    print("list is empty")
    
# reading each element from the list
# iterate the list
for val in alist:
        print(val)    

# range(start,stop,step) # default step is 1
for val in range(1,11):
    print(val)

print(alist)
for val in alist[0:3]:
    print(val)    

for val in range(10,1,-1):
    print(val)

for val in range(1,11,2):
    print(val)

name = "python programing"
for char in name[::2]:
    print(char)













