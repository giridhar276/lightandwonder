# single screenshot
import pyautogui
# Capture the entire screen
screenshot = pyautogui.screenshot()
screenshot.save('selected_region.png')


# capturing series of screenshoots

import time
import os

for val in range(1,50):
    time.sleep(3)
    screenshot = pyautogui.screenshot()
    filename = time.strftime("%d_%b_%Y_%S.jpg")
    filename = str(val) + filename
    screenshot.save(filename)
    